import pandas as pd
import matplotlib
matplotlib.use('Agg') # ¡Importante! Usa un backend no interactivo para servidor
import matplotlib.pyplot as plt
import io       # Para manejar el buffer de la imagen en memoria
import base64   # Para codificar la imagen para HTML
from flask import Flask, render_template # Importa lo necesario de Flask

# --- Inicializa la aplicación Flask ---
app = Flask(__name__)

# --- Define la ruta principal ('/') ---
@app.route('/')
def index():
    """
    Esta función se ejecuta cuando alguien visita la raíz del sitio web.
    Carga los datos, los limpia, genera UNA gráfica y la envía a la plantilla HTML.
    """
    img_buffer = io.BytesIO() # Crea un buffer en memoria para la imagen
    plot_data_base64 = None # Inicializa por si hay errores

    try:
        # --- 1. Carga de Datos ---
        file_path = 'datos.csv' # Asume que está en el mismo directorio que app.py
        df = pd.read_csv(file_path)
        print(f"Archivo '{file_path}' cargado exitosamente.")

        # --- 2. Limpieza y Manipulación de Datos (Adaptado de tu script) ---
        print("Limpiando y preparando datos...")
        try:
            # Convertir 'Invoice Date' a datetime (si existe)
            if 'Invoice Date' in df.columns:
                df['Invoice Date'] = pd.to_datetime(df['Invoice Date'])
            else:
                 print("Advertencia: Columna 'Invoice Date' no encontrada.")

            # Eliminar 'Retailer ID' (si existe)
            if 'Retailer ID' in df.columns:
                df = df.drop(columns=['Retailer ID'])
            else:
                print("Advertencia: Columna 'Retailer ID' no encontrada para eliminar.")

            # Limpiar y convertir 'Total Sales' (si existe)
            if 'Total Sales' in df.columns:
                df['Total Sales'] = df['Total Sales'].astype(str).str.replace(',', '').str.replace('$', '')
                df['Total Sales'] = pd.to_numeric(df['Total Sales'])
            else:
                 print("Advertencia: Columna 'Total Sales' no encontrada.")
                 # Si falta 'Total Sales', muchas gráficas fallarán. Podríamos detenernos aquí.
                 # return "Error: Falta la columna 'Total Sales' en los datos.", 500

            # Limpiar y convertir 'Operating Profit' (si existe)
            if 'Operating Profit' in df.columns:
                 df['Operating Profit'] = df['Operating Profit'].astype(str).str.replace(',', '').str.replace('$', '')
                 df['Operating Profit'] = pd.to_numeric(df['Operating Profit'])
            else:
                print("Advertencia: Columna 'Operating Profit' no encontrada.")

            print("Datos limpiados:")
            print(df.head()) # Muestra las primeras filas para verificar

        except KeyError as e:
            print(f"Error: Columna clave no encontrada durante la limpieza: {e}")
            return f"Error: Falta la columna '{e}' requerida para la limpieza.", 500
        except Exception as clean_err:
            print(f"Error inesperado durante la limpieza de datos: {clean_err}")
            return f"Error inesperado durante la limpieza: {clean_err}", 500

        # --- 3. Creación de la Gráfica (ELIGE UNA OPCIÓN DESCOMENTANDO) ---
        print("Generando gráfica...")
        fig, ax = plt.subplots(figsize=(12, 7)) # Ajusta tamaño si es necesario

        # --- OPCIÓN 1: Ventas Totales por Retailer (ACTIVA POR DEFECTO) ---
        print("-> Graficando: Ventas por Retailer")
        try:
            if 'Retailer' in df.columns and 'Total Sales' in df.columns:
                ventas_por_retailer = df.groupby('Retailer')['Total Sales'].sum()
                ax.bar(ventas_por_retailer.index, ventas_por_retailer.values)
                ax.set_title('Ventas Totales por Retailer')
                ax.set_xlabel('Retailer')
                ax.set_ylabel('Ventas Totales ($)')
                # Rotar etiquetas si hay muchos retailers
                if len(ventas_por_retailer) > 10:
                     plt.xticks(rotation=70, ha="right")
                else:
                     plt.xticks(rotation=0)
                plt.tight_layout() # Ajusta para que quepan las etiquetas
            else:
                 print("Error: Faltan columnas 'Retailer' o 'Total Sales' para gráfica 1.")
                 ax.text(0.5, 0.5, 'Error: Faltan datos para\nVentas por Retailer', ha='center', va='center', color='red')
        except Exception as e1:
            print(f"Error al generar gráfica 1: {e1}")
            ax.text(0.5, 0.5, f'Error al generar gráfica:\n{e1}', ha='center', va='center', color='red')


        # --- OPCIÓN 2: Ventas Totales por Método de Venta (COMENTADA) ---
        # Descomenta este bloque (y comenta el de arriba) para mostrar esta gráfica
        # print("-> Graficando: Ventas por Método de Venta")
        # try:
        #     if 'Sales Method' in df.columns and 'Total Sales' in df.columns:
        #         ventas_por_metodo = df.groupby('Sales Method')['Total Sales'].sum()
        #         ax.bar(ventas_por_metodo.index, ventas_por_metodo.values, color=['skyblue', 'lightcoral', 'lightgreen']) # Colores opcionales
        #         ax.set_title('Ventas Totales por Método de Venta')
        #         ax.set_xlabel('Método de Venta')
        #         ax.set_ylabel('Ventas Totales ($)')
        #         plt.xticks(rotation=0)
        #         plt.tight_layout()
        #     else:
        #         print("Error: Faltan columnas 'Sales Method' o 'Total Sales' para gráfica 2.")
        #         ax.text(0.5, 0.5, 'Error: Faltan datos para\nVentas por Método', ha='center', va='center', color='red')
        # except Exception as e2:
        #     print(f"Error al generar gráfica 2: {e2}")
        #     ax.text(0.5, 0.5, f'Error al generar gráfica:\n{e2}', ha='center', va='center', color='red')


        # --- OPCIÓN 3: Ventas a lo largo del tiempo (COMENTADA) ---
        # Descomenta este bloque (y comenta los otros) para mostrar esta gráfica
        # print("-> Graficando: Tendencia de Ventas en el Tiempo")
        # try:
        #     if 'Invoice Date' in df.columns and 'Total Sales' in df.columns and pd.api.types.is_datetime64_any_dtype(df['Invoice Date']):
        #         ventas_por_fecha = df.groupby(df['Invoice Date'].dt.date)['Total Sales'].sum()
        #         ax.plot(ventas_por_fecha.index, ventas_por_fecha.values, marker='.', linestyle='-') # Marcador pequeño
        #         ax.set_title('Tendencia de Ventas a lo largo del Tiempo')
        #         ax.set_xlabel('Fecha')
        #         ax.set_ylabel('Ventas Totales ($)')
        #         plt.xticks(rotation=45, ha="right")
        #         ax.grid(True) # Añadir cuadrícula para mejor lectura
        #         plt.tight_layout()
        #     else:
        #          print("Error: Falta 'Invoice Date' (tipo fecha) o 'Total Sales' para gráfica 3.")
        #          ax.text(0.5, 0.5, 'Error: Faltan datos para\nTendencia de Ventas', ha='center', va='center', color='red')
        # except Exception as e3:
        #     print(f"Error al generar gráfica 3: {e3}")
        #     ax.text(0.5, 0.5, f'Error al generar gráfica:\n{e3}', ha='center', va='center', color='red')


        # --- Convertir Gráfica a Imagen en Memoria y Codificarla ---
        print("Guardando gráfica en buffer...")
        plt.savefig(img_buffer, format='png', bbox_inches='tight') # bbox_inches='tight' ayuda a evitar recortes
        img_buffer.seek(0) # Rebobina el buffer al inicio
        print("Codificando imagen a Base64...")
        plot_data_base64 = base64.b64encode(img_buffer.getvalue()).decode('utf-8')
        print("Imagen lista para enviar.")


    except FileNotFoundError:
        print(f"Error Fatal: No se encontró el archivo '{file_path}'.")
        # Renderiza la plantilla pero indica el error (o podrías mostrar una página de error)
        return render_template('index.html', error_message=f"Error: No se encontró el archivo de datos '{file_path}'.")
    except pd.errors.EmptyDataError:
         print(f"Error Fatal: El archivo '{file_path}' está vacío.")
         return render_template('index.html', error_message=f"Error: El archivo de datos '{file_path}' está vacío.")
    except Exception as e:
        print(f"Error inesperado en la ruta principal: {e}")
        # Renderiza la plantilla pero indica el error general
        return render_template('index.html', error_message=f"Ocurrió un error inesperado: {e}")
    finally:
        # Asegúrate de cerrar la figura de Matplotlib para liberar memoria,
        # incluso si hubo un error antes de codificarla.
        if 'fig' in locals() and fig is not None:
            plt.close(fig)
            print("Figura de Matplotlib cerrada.")


    # --- Renderizar la Plantilla HTML ---
    # Pasa la cadena Base64 (o None si hubo error antes de codificar) a la plantilla
    return render_template('index.html', plot_data=plot_data_base64)


# --- Ejecutar la aplicación ---
if __name__ == '__main__':
    # debug=True es útil para desarrollo (recarga automática, muestra errores)
    # ¡Quítalo o ponlo en False para producción!
    app.run(debug=True, host='0.0.0.0') # host='0.0.0.0' permite acceso desde otros dispositivos en la red local